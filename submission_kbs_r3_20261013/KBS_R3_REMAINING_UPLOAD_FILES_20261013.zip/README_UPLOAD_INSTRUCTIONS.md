# KBS R3 remaining upload files

**Manuscript:** KNOSYS-D-26-07461R3

Extract this outer ZIP before uploading individual files to Editorial Manager.

1. Upload `TO_UPLOAD/KBS_R3_COMPLETE_LATEX_SOURCE.zip` under **LaTeX source files**. It contains the validated R3 `main.tex`, `main.bbl`, `refs.bib`, `elsarticle.cls`, and `elsarticle-num.bst`.
2. If a standalone `main.tex` attachment is already present in Editorial Manager, replace or remove it as needed so that duplicate or conflicting source versions are not left in the submission.
3. Upload `TO_UPLOAD/06_Declaration_of_Interest_R3.docx` only if replacing the previously carried-forward declaration. The sole content change is the manuscript identifier, now `KNOSYS-D-26-07461R3`.
4. Handle the official author agreement separately. No official form was found locally. Follow `AUTHOR_ACTION_REQUIRED/AUTHOR_AGREEMENT_REQUIRED.txt` and obtain the publisher-issued form or complete the official Editorial Manager approval process. This item is **not ready for submission**.
5. Do not upload this outer ZIP directly as the manuscript or as a LaTeX source file.
6. Do not reupload the already verified manuscript PDF, response to reviewers, cover letter, or highlights unless Editorial Manager requires it.

This package does not change the validated manuscript, figures, reviewer response, cover letter, highlights, or experimental results. It has not been submitted to Editorial Manager.
