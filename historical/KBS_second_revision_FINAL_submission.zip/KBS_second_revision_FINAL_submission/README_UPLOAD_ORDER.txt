KBS second-revision upload package
Manuscript: KNOSYS-D-26-07461R1
Title: Decision-aligned eviction-value prediction for learning-augmented caching

This ZIP is a convenience package. Editorial Manager typically requires
files to be uploaded individually. Do not assume the ZIP itself is the
manuscript source unless the system explicitly allows a source ZIP.

Upload in this order (use the current files in this folder):

1. Revised manuscript:
   01_Revised_Manuscript.pdf

2. Response to reviewers:
   02_Response_to_Reviewers.docx
   (02_Response_to_Reviewers.md is the canonical text source; upload DOCX
   unless Editorial Manager requests Markdown.)

3. Cover letter:
   03_Cover_Letter.docx

4. Highlights:
   04_Highlights.docx

5. CRediT statement:
   05_CRediT_Author_Statement.docx

6. Declaration of Interest:
   06_Declaration_of_Interest.docx

7. Author agreement:
   NOT IN THIS PACKAGE.
   Complete the official Elsevier/KBS form in Editorial Manager and upload
   that file. See 07_Author_Agreement_NOT_INCLUDED.txt.

8. LaTeX source:
   Upload the files in LaTeX_Source/ using Editorial Manager's LaTeX source
   item category:
     main.tex
     refs.bib
     elsarticle.cls
     elsarticle-num.bst
   Figure 1 is TikZ in main.tex. There are no separate current figure PNGs.

DO NOT upload historical files from a previous revision when a new current
file is provided here. Do not upload files whose titles contain "robust".
Do not upload old June/April packages, manuscript_source PDFs, or
historical ZIPs.

Public repository (supporting evidence, not an Editorial Manager item):
https://github.com/SoroushVahidi/Augmented-caching
Reviewer landing page:
https://github.com/SoroushVahidi/Augmented-caching/blob/main/docs/reviewer/START_HERE.md
